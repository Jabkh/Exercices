<script setup>
import FormList from './components/FormList.vue';
</script>

<template>
  

<div>
<h1>Saisir des tâches : </h1>
<FormList/>
</div>


</template>

<style scoped>

</style>
